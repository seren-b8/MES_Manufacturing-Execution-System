import { Controller } from '@nestjs/common';

@Controller('assign-log')
export class AssignLogController {}
