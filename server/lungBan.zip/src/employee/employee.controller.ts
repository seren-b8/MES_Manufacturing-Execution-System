import { Controller } from '@nestjs/common';

@Controller('employee')
export class EmployeeController {}
