import { Controller } from '@nestjs/common';

@Controller('machine-cavity')
export class MachineCavityController {}
